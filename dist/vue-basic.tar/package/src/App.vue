<template>
    <div id="app">
        BFUN!!!
    </div>
</template>

<script>
    export default {}
</script>

<style lang="less">
    #app {
        background-color: #f0f0f0;
    }
</style>
