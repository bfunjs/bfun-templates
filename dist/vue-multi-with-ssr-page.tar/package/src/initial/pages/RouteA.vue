<template>
    <div class="page-a">
        Page A
    </div>
</template>

<script>
    export default {}
</script>

<style lang="less">
</style>
