import { createApp } from "./index";

const { app } = createApp();
app.$mount('#app');
