module.exports = {
    solutions: [ '@bfun/solution-component' ],
};