<template>
    <div id="app">
        BFUN!!!
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('hello world');
        }
    }
</script>

<style lang="less">
    #app {
        background: #fff;
    }
</style>
