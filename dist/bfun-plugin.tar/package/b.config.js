module.exports = {
    solutions: [ '@bfun/solution-plugin' ],
};