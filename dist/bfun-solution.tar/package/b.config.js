module.exports = {
    solutions: [ '@bfun/solution-solution' ],
};